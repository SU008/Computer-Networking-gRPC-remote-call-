﻿using System;
using System.Threading.Tasks;
using Grpc.Net.Client;
//using GrpcServer;

namespace GrpcClient
{
    public class ClientProgram
    {
        public float RetSquare(float x)
            /*public static void Main(string[] args)   for console*/
        
            {
            //creating a GrpcChannel using the URL of our service
            var channel = GrpcChannel.ForAddress("https://localhost:5001");

            
            var client = new Square.SquareClient(channel); 
            //now we can use the client instance to call the RetSquare method


            var request = new SquareRequest { Inval = x };  // passes input value of function to create a new request
            var response = client.RetSquare(request);        // use request to return reply from server

            // ***** needed for console app
            // Console.WriteLine("Answer:" + response.Outval);                                                                              
            // Console.ReadLine();

            return response.Outval;  //  give calculator app the x^2 answer
        }
    }
}
