﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Grpc.Core;

namespace GrpcServer.Services
{
    //The generated squareService class contains the implementation of the service
    public class squareService : Square.SquareBase // inherits abstract base class
    {
        private readonly ILogger<squareService> _logger;
        public squareService(ILogger<squareService> logger)
        {
            _logger = logger;
        }

       
        public override Task<SquareReply> RetSquare(SquareRequest request, ServerCallContext context)
        {
            return Task.FromResult(new SquareReply { Outval = request.Inval * request.Inval });         // square function is implemented
        }
        

    }
}
